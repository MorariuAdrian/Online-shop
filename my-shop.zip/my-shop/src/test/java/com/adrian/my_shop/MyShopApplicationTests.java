package com.adrian.my_shop;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MyShopApplicationTests {

	@Test
	void contextLoads() {
	}

}
