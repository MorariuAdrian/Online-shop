package com.adrian.my_shop.enums;

public enum CategoryType {
    WOMEN, MEN, KIDS, ELECTRONICS, TOOLS, PETS, BOOKS;
}
