package com.adrian.my_shop.dto;

import lombok.Data;

@Data
public class SelectionDto {
    private String quantity;
}
