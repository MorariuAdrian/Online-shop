package com.adrian.my_shop.enums;

public enum OrderStatus {
    NEW, ACCEPTED, IN_DELIVERY, DELIVERED, CANCELED;
}
