package com.adrian.my_shop.enums;

public enum UserRole {
    ROLE_BUYER, ROLE_SELLER;
}
